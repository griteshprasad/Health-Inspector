# Realtime Form Validation

![](https://bitsofco.de/content/images/2016/06/Realtime_Validation2.gif)

## [Read the Blog Post](https://bitsofco.de/realtime-form-validation/#comment-2754183495)

This branch hold a slighlty updated version of the original. If you're coming from the [video tutorial](https://youtu.be/m4Fru330HqQ), you should checkout out the [the original repository](https://github.com/ireade/form-validation-realtime/tree/original) for the version from that video. 

## Changes + Contributors

- [Commit 2f552735...](https://github.com/ireade/form-validation-realtime/commit/2f552735aee98e22d453fc0e22f30b479e4d9f0a) - [@sarbbottam](https://github.com/sarbbottam) added an event listener for submit of the form
- [Commit 2a3e0ad0...](https://github.com/ireade/form-validation-realtime/commit/2a3e0ad0d3bd882aecf619ddb4985b608ec5391a) - [@salisadecade](https://github.com/salisadecade) Encapsulated `checkInput` and event registration

- [ES6 Version](https://github.com/whizkydee/form-validation-realtime) - [@whizkydee](https://github.com/whizkydee) created a version of this written in ES6
